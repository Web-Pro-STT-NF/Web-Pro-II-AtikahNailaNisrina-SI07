<div style="background-color: #1E90FF; height:60px;">
<footer class="d-flex justify-content-center pt-3">
<p>Created by <a class="text-dark" href="http://nurulfikri.ac.id">Pusinfo NF &copy;2017</a></p>
</footer>
</div>