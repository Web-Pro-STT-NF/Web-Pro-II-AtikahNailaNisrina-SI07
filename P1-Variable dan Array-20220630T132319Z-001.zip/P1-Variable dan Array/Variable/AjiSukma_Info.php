<?php
    phpinfo();
?>

